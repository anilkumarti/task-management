import React from 'react'
import SignIn from '../components/auth/SignIn'

const Auth = () => {
  return (
    <div>
        <SignIn/>
    
    </div>
  )
}

export default Auth
